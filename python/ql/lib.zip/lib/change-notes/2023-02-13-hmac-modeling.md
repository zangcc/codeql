---
category: minorAnalysis
---
* Added modeling of cryptographic operations in the `hmac` library.
