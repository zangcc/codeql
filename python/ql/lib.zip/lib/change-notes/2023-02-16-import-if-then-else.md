---
category: minorAnalysis
---
* Fixed module resolution so we properly recognize definitions made within if-then-else statements.
